<?php
session_start();
$admin_password = 'admin123';  // Change this to secure the admin area

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];
    if ($password === $admin_password) {
        $_SESSION['admin'] = true;
        header('Location: admin_panel.php');
    } else {
        echo 'Mot de passe incorrect';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <h1>Connexion Admin</h1>
    </header>
    <main>
        <form action="admin.php" method="POST">
            <label for="password">Mot de passe :</label>
            <input type="password" id="password" name="password">
            <button type="submit">Connexion</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2024 Scouts et Guides de France - Farfadets</p>
    </footer>
</body>
</html>
